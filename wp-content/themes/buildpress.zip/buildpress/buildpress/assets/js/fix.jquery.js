/**
 * jQuery module fix
 */
/*global define, jQuery*/
define( [], function () {
	'use strict';
	return jQuery;
} );